package com.example.project15;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class the_Activity extends Activity {
    @Override
    protected void onCreate( @Nullable Bundle savedInstanceState ) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.xxx );
    }
    public void back( View view ) {
        Intent intent = new Intent ( this , MainActivity.class );
        startActivity ( intent );
    }
}
